#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#define rg register
using namespace std;
const int MAXN1=2e5+50,MAXN2=2100,MOD=1e9+7,S=2050;
typedef long long LL;
LL N,a[MAXN1],b[MAXN1],mul[MAXN2<<2],invv[MAXN2<<2],f[MAXN2<<1][MAXN2<<1],ans=0;
inline LL qpow(LL a,LL b){//??? 
	LL res=1;
	while(b){
		if(b&1) res=(res*a)%MOD;
		b>>=1;
		a=(a*a)%MOD;
	}
	return res;
}
inline LL inv(LL x){return qpow(x,MOD-2)%MOD;}//??? 
inline LL C(LL n,LL m){return mul[n]*invv[n-m]%MOD*invv[m]%MOD;}//???? 
int main()
{
	memset(f,0,sizeof(f));
	scanf("%lld",&N);
	for(rg LL i=1;i<=N;i++) scanf("%lld%lld",&a[i],&b[i]),f[S-a[i]][S-b[i]]++;//???????dp???? 
	mul[0]=1,invv[0]=inv(mul[0]);//?????????? 
	for(rg LL i=1;i<=8000;i++) mul[i]=mul[i-1]*i%MOD,invv[i]=inv(mul[i]);
	for(rg LL i=1;i<=S*2;i++)//dp 
		for(rg LL j=1;j<=S*2;j++)
			f[i][j]=(f[i][j]+(f[i-1][j]+f[i][j-1])%MOD)%MOD;
	for(rg LL i=1;i<=N;i++){
		ans=(ans+f[S+a[i]][S+b[i]])%MOD;//???? 
		ans=(ans-C(2*a[i]+2*b[i],2*a[i]))%MOD;//??????? 
		ans=(ans+MOD)%MOD;//??ans??? 
	}
	ans=(ans*500000004)%MOD;//???,????2??? 
	printf("%lld\n",ans);
	return 0;
}

