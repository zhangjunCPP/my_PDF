#pragma GCC optimize ("unroll-loops")
#pragma GCC optimize (2)
#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#define N 5007
#define ll long long
#define p 1000000007
#define reg register
using namespace std;
 
inline int power(int a,int t){
    int res = 1;
    while(t){
        if(t&1) res = (ll)res*a%p;
        a = (ll)a*a%p;
        t >>= 1;
    }
    return res;
}
 
int n,m,k,cnt;
int f[N],inv[N],pw[N],pr[N>>1],c[N];
 
int solve1(){
    int res = 0;
    for(reg int i=1;i<=n;++i) res = (res+(ll)c[i]*pw[i])%p;
    return res;
}
 
const int w = 500000003;
 
int solve2(){
    int c2,mul,res = 0;
    mul = c2 = f[k] = 1;
    for(reg int i=k-1;i;--i){
        c2 = (ll)c2*(n-i-1)%p*inv[k-i]%p;
        mul = (ll)mul*w%p;
        f[i] = ((ll)c2*mul+(ll)(w+1)*f[i+1])%p;
    }
    mul = p-w;
    for(reg int i=1;i<=k;++i){
        res = (res+(ll)pw[i]*c[i]%p*mul%p*f[i])%p;
        mul = (ll)mul*(p-w)%p;
    }
    res = (ll)res*power(2,n)%p;
    return res;
}
 
int main(){
    scanf("%d%d%d",&n,&k);
    c[0] = inv[1] = pw[1] = 1;
    c[1] = n;
    for(reg int i=2;i<=k+1;++i){
        inv[i] = (ll)(p-p/i)*inv[p%i]%p;
        c[i] = (ll)c[i-1]*inv[i]%p*(n-i+1)%p;
        if(!pw[i]){
            pr[++cnt] = i;
            pw[i] = power(i,k);
        }
        for(reg int j=1;j<=cnt&&i*pr[j]<=k;++j){
            pw[i*pr[j]] = (ll)pw[i]*pw[pr[j]]%p;
            if(i%pr[j]==0) break;
        }
    }
    if(n<=k+1) printf("%d",solve1());
    else printf("%d",solve2());
    return 0;	
}

