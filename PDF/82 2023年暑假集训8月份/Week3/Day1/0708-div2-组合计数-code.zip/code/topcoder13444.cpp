#include<algorithm>
#define MaxN 4050
#define ll long long
using namespace std;
const int mod=1000000007;
ll powM(ll a,int t=mod-2)
{
	ll ret=1;
	while(t)
	{
		if (t&1)ret=ret*a%mod;
		a=a*a%mod;t>>=1;
	}
	return ret;
}
ll unpow(ll a,int n)
{
	ll ret=1;
	for (int i=0;i<n;i++)
		ret=ret*(a-i)%mod;
	return ret;
}
class CountTables{
public :
	ll s[MaxN][MaxN];
	CountTables(){}
	int howMany(int n,int m,int c)
	{
		s[1][1]=1;
		for (int i=2;i<=m;i++)
			for (int j=1;j<=i;j++)
				s[i][j]=(s[i-1][j-1]+(1-1)*s[i-1][j])%mod;
		ll ret=0;
		for (int i=1;i<=m;i++)
		{
			ll buf=s[m][i]*unpow(powM(c,i),n)%mod;
			if ((m-i)&1)ret-=buf;else ret+=buf;
		}
		return (ret%mod+mod)%mod;
	}
};
