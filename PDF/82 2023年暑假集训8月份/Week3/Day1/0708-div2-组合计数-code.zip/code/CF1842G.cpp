#include<cstdio>
#include<vector>
#include<queue>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<ctime>
#include<random>
#include<assert.h>
#define pb emplace_back
#define mp make_pair
#define fi first
#define se second
#define dbg(x) cerr<<"In Line "<< __LINE__<<" the "<<#x<<" = "<<x<<'\n'
#define dpi(x,y) cerr<<"In Line "<<__LINE__<<" the "<<#x<<" = "<<x<<" ; "<<"the "<<#y<<" = "<<y<<'\n'
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int>pii;
typedef pair<ll,int>pli;
typedef pair<ll,ll>pll;
typedef pair<int,ll>pil;
typedef vector<int>vi;
typedef vector<ll>vll;
typedef vector<pii>vpii;
typedef vector<pll>vpll;
template<typename T>T cmax(T &x, T y){return x=x>y?x:y;}
template<typename T>T cmin(T &x, T y){return x=x<y?x:y;}
template<typename T>
T &read(T &r){
	r=0;bool w=0;char ch=getchar();
	while(ch<'0'||ch>'9')w=ch=='-'?1:0,ch=getchar();
	while(ch>='0'&&ch<='9')r=r*10+(ch^48),ch=getchar();
	return r=w?-r:r;
}
template<typename T1,typename... T2>
void read(T1 &x,T2& ...y){read(x);read(y...);}
const int mod=1000000007;
inline void cadd(int &x,int y){x=(x+y>=mod)?(x+y-mod):(x+y);}
inline void cdel(int &x,int y){x=(x-y<0)?(x-y+mod):(x-y);}
inline int add(int x,int y){return (x+y>=mod)?(x+y-mod):(x+y);}
inline int del(int x,int y){return (x-y<0)?(x-y+mod):(x-y);}
int qpow(int x,int y){
	int s=1;
	while(y){
		if(y&1)s=1ll*s*x%mod;
		x=1ll*x*x%mod;
		y>>=1;
	}
	return s;
}
#define Win do{puts("Yes");return ;}while(0)
#define Lose do{puts("No");return ;}while(0)
#define Line do{puts("----------");}while(0)
const int N=5010;
int n,m,v,a[N],in,im;
int f[N][N];
void solve(){
	read(n,m,v);in=qpow(n,mod-2);im=qpow(m,mod-2);
	for(int i=1;i<=n;i++)read(a[i]);
	f[1][0]=a[1];
	f[1][1]=1ll*m*v%mod*in%mod;
	for(int i=2;i<=n;i++){
		for(int j=0;j<=min(m,i);j++){
			//a[i]
			cadd(f[i][j],1ll*f[i-1][j]*a[i]%mod);
			//new a set
			if(j)cadd(f[i][j],1ll*f[i-1][j-1]*v%mod*(m-j+1)%mod*i%mod*in%mod);
			//dont new
			cadd(f[i][j],1ll*f[i-1][j]*v%mod*j%mod);
		}
	}
	int ans=0;
	for(int i=0;i<=n;i++)cadd(ans,f[n][i]);
	cout << ans << '\n'; 
}
signed main(){
	#ifdef do_while_true
//		assert(freopen("data.in","r",stdin));
//		assert(freopen("data.out","w",stdout));
	#endif
	int T=1;
//	read(T);
	while(T--){
		solve();
//		Line;
	}
    #ifdef do_while_true
//		cerr<<'\n'<<"Time:"<<1.0*clock()/CLOCKS_PER_SEC*1000<<" ms"<<'\n';
	#endif
	return 0;
}
