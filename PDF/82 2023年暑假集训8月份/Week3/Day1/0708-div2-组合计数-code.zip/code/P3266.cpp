#include<iostream>
using namespace std;
const int P=1e9+7,N=3e6+10;
int n,m,up,inv[N],jc[N],inj[N];
int Calc(int x,int y) {return (x<0||y<0)?0:1ll*jc[x+y]*inj[x]%P*inj[y]%P;}
void flip1(int &x,int &y) {swap(x,y);x--;y++;}
void flip2(int &x,int &y) {swap(x,y);x+=m+2;y-=m+2;}
void add(int &x,int y) {x+=y;if(x>=P) x-=P;}
int main()
{
	cin>>n>>m;inv[0]=inv[1]=jc[0]=inj[0]=1;up=max(n,m)*3+1;
	for(int i=2;i<=up;i++) inv[i]=(P-1ll*P/i*inv[P%i]%P)%P;
	for(int i=1;i<=up;i++) jc[i]=1ll*jc[i-1]*i%P,inj[i]=1ll*inj[i-1]*inv[i]%P;
	int x=n+m+1,y=n,ans=Calc(x,y);
	while(x>=0&&y>=0)
	{
		flip1(x,y);add(ans,P-Calc(x,y));
		flip2(x,y);add(ans,Calc(x,y));
	}
	x=n+m+1,y=n;
	while(x>=0&&y>=0)
	{
		flip2(x,y);add(ans,P-Calc(x,y));
		flip1(x,y);add(ans,Calc(x,y));
	}
	return cout<<ans<<endl,0;
}

